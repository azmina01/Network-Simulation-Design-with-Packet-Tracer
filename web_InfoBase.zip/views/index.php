<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Info Base</title>
  <link rel="stylesheet" href="/static/css/style.css">

</head>

<body>
  <main>
    <div id="border">
      <wrapper>
        <scroller id="scroller">
          <content id="blog-content">
            <div class="my-post text">
              <h2>Nexagate</h2>
              <p>> CyberSecurity as a Service</p>
              <p>> Ensuring Everyone's Safety in the Cyberspace</p>
            </div>
            <div class="my-post text">
              <h2>Security Risk & Compliance</h2>
              <p># ISMS / ISO27001 Consulting... READY</p>
              <p># RMIT Cyber Risk Consulting... READY</p>
              <p># Data Loss Prevention (DLP)... READY</p>
              <p># Business Continuity Consulting... READY</p>
              <p># ITSM / ISO20000 Consulting... READY</p>
            </div>
            <div class="my-post text">
              <h2>Offensive Security Assessment</h2>
              <p># Security Penetration Testing... READY</p>
              <p># Cloud Security Assessment... READY</p>
              <p># IOT & ICS Security Assessment... READY</p>
              <p># Compromise Assessment... READY</p>
              <p># Red Teaming... READY</p>
            </div>
            <div class="my-post text">
              <h2>Managed Security Services</h2>
              <p># Managed Cloud Security... READY</p>
              <p># Managed SIEM & Monitoring... READY</p>
              <p># Managed Endpoint Protection... READY</p>
              <p># Managed Detection & Response... READY</p>
              <p># Managed Web Security... READY</p>
            </div>
          </content>
          <scrollbar></scrollbar>
        </scroller>
        <div id="celia-window">
          <div id="term-container">
            <div id="term"></div>
            <div id="term-entry">
              <div>
                ><input type="text" class="c3" maxlength="140" />
              </div>
            </div>
          </div>
        </div>
      </wrapper>
    </div>
    <sidebar>
      <a id="side-int" class="s" href="#">
        <p>Status</p>
        <img style="height: 80%;" src="/static/images/face.png" />
      </a>
      <a id="side-needs" class="s" href="#">
        <p>Needs</p>
        <img src="/static/images/needs.png" />
      </a>
      <a id="side-celia" class="s" href="#">
        <p>Command</p>
        <img style="height: 70%;" src="/static/images/terminal.png" />
      </a>
    </sidebar>
    <div id="integer-status" class="pop">
      <div class="ribbon">// Company_Status<close>X</close>
      </div>
      <img id="integer" src="/static/images/figure.png" />
      <p class="codetext">
        Since: 2010<br /><br />
        Founders: Khairil Effendy<br /><br />
        Certified: ISO 27001:2013, CREST-accredited<br /><br />
        Completed Project: 500+<br /><br />
        Current Aim: Improve everyone security processes, achieve compliance and protect data from leakages and threats.
      </p>
    </div>
    <div id="needs" class="pop red">
      <div class="ribbon">// Needs<close>X</close>
      </div>
      <div class="scrollbox">
        <span class="dirtitle">Power Status: </span>
        <div class="dirtitleAfter"></div>
        <ul class="dir">
          <li>> Current Power: 150%</li>
          <li>> Time Left: 16h 52m</li>
        </ul>
        <span class="dirtitle">Maintenance Info: </span>
        <div class="dirtitleAfter"></div>
        <ul class="dir">
          <li>> Health: 94%</li>
          <li>> Repair: N/A</li>
        </ul>
      </div>
    </div>
  </main>
  <!-- partial -->
  <script src='/static/js/jquery.js'></script>
  <script src="/static/js/script.js"></script>

</body>

</html>